$(document).ready(function(){

    $(".delete-estudiante").on("click", function(e){

        e.preventDefault();
        if(confirm("Estas Seguro que Quieres Eliminar Este Estudiante")){

            let id =  $(this).data("id");

            window.location.href = "Estudiantes/delete.php?id=" + id;
        }

    });

});