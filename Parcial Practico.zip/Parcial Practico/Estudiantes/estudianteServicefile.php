<?php

class EstudianteServiceFile implements IServiceBase{
    
    private $utility;
    public $filehandler;
    public $directory;
    public $filename;

    public function __construct($directory = "data"){

        $this->utility = new Utility();
        $this->directory = $directory;
        $this->filename = "Estudiantes";
        $this->filehandler = new JsonFileHandler($this->directory, $this->filename);
        
    }

    public function GetList(){

        $listadoEstudiantesDecode =  $this->filehandler->ReadFile();
        $listadoEstudiantes = array();

        if($listadoEstudiantesDecode == false){
            $this->filehandler->SaveFile($listadoEstudiantes); 
            
        } 
        else{
           
            foreach($listadoEstudiantesDecode as $elementDecode){
                $element = new estudiantes();
                $element->set($elementDecode);

                array_push($listadoEstudiantes, $element);
            }

        }

        return $listadoEstudiantes;


    }

    public function GetById($id){
        $listadoEstudiantes = $this->GetList();
        $estudiante = $this->utility->searchProperty($listadoEstudiantes, 'id', $id)[0];
        return $estudiante;
    }

    public function Add($entity){
        $listadoEstudiantes = $this->GetList();
        $estudianteId = 1;

        if(!empty($listadoEstudiantes)){
            $lastEstudiante = $this->utility->getLastElement($listadoEstudiantes);
            $estudianteId = $lastEstudiante->id + 1;
        }

        $entity->id = $estudianteId;
        $entity->profilePhoto = "";

        if(isset($_FILES['profilePhoto'])){

            $photoFile = $_FILES['profilePhoto'];

            if($photoFile['error'] == 4){
                $entity->profilePhoto = "";
            }

            else{

            $typeReplace = str_replace("image/","", $photoFile ['type']);
            $type =  $photoFile ['type'];
            $size =  $photoFile ['size'];
            $name =  $estudianteId. '.'. $typeReplace;
            $tmpname =  $photoFile ['tmp_name'];

            $success = $this->utility->UploadImage('../Asset/img/estudiantes/',$name, $tmpname, $type, $size);

            if($success){
                $entity->profilePhoto = $name;

            }

            
            
            }

        }

        array_push($listadoEstudiantes, $entity);

        $this->filehandler->SaveFile($listadoEstudiantes);
    }

    public function Update($id, $entity){
        $element = $this->GetById($id);
        $listadoEstudiantes = $this->GetList();

        $elementIndex = $this->utility->getIndexElement($listadoEstudiantes,'id',$id);

        if(isset($_FILES['profilePhoto'])){

            $photoFile = $_FILES['profilePhoto'];

            if($photoFile['error'] == 4){
                $entity->profilePhoto = $element->profilePhoto;
            }

            else{
                
            $typeReplace = str_replace("image/","",$photoFile ['type']);
            $type = $photoFile ['type'];
            $size = $photoFile ['size'];
            $name =  $id. '.'. $typeReplace;
            $tmpname = $photoFile ['tmp_name'];

            $success = $this->utility->UploadImage('../Asset/img/estudiantes/',$name, $tmpname, $type, $size);

            if($success){
                $entity->profilePhoto = $name;
            }

            }
            
        }

        $listadoEstudiantes[$elementIndex] = $entity;

        $this->filehandler->SaveFile($listadoEstudiantes);
    }

    public function Delete($id){
        $listadoEstudiantes = $this->GetList();
        $elementIndex = $this->utility->getIndexElement($listadoEstudiantes,'id',$id);

        unset($listadoEstudiantes[$elementIndex]);

        $listadoEstudiantes = array_values($listadoEstudiantes);

        $this->filehandler->SaveFile($listadoEstudiantes);
    }
}

?>