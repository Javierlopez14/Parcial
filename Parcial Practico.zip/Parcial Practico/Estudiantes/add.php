<?php 

  require_once '../layout/layout.php';
  require_once '../helper/utility.php';
  require_once 'estudiantes.php';
  require_once '../service/IService.php';
  require_once 'estudianteServiceCookie.php';
  require_once '../helper/fileHandler/iFileHandler.php';
  require_once '../helper/fileHandler/JsonFileHandler.php';
  require_once 'estudianteServicefile.php';

  $layout = new Layout(true);
  $service = new EstudianteServiceFile();
  $utility = new Utility();

  if(isset($_POST['nombre']) && isset($_POST['apellido']) && 
     isset($_POST['estado']) && isset($_POST['carrera']) && isset($_FILES['profilePhoto'])){

    $nuevoEstudiante = new estudiantes();

    $nuevoEstudiante->InicializeDate(0, $_POST['nombre'], $_POST['apellido'], $_POST['estado'], $_POST['carrera'],
                                        $_FILES['profilePhoto']);

    $service->Add($nuevoEstudiante);
       
    header("Location: ../index.php");
    exit();
  }

?>


<?php 
 $layout->PrintHeader();
?>

<main role="main">
   
    <div style="margin-top: 2%;" class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-dark text-light">
                    <h4>AGREGAR NUEVO ESTUDIANTE</h4>
                    <a href="../index.php" class="btn btn-warning">Volver Atras</a>
                </div>
            <div class="card-body">

                <form enctype="multipart/form-data" action="add.php" method="POST">

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" class="form-control" placeholder="Nombre" name="nombre">
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" class="form-control" placeholder="Apellido" name="apellido">
                    </div>



                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select name="estado" id="estado" class="form-control">
                            <?php foreach($utility->estado as $id => $text): ?> 

                                <option value="<?php echo $id;?>"> <?php echo $text;?> </option>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="carrera">Carrera</label>
                        <select name="carrera" class="form-control" id="carrera">
                            <?php foreach($utility->carrera as $id => $text): ?>  

                                <option value="<?php echo $id;?>"> <?php echo $text;?> </option>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="photo">FOTO DE PERFIL:</label>
                        <input type="file" class="form-control" placeholder="Photo" name="profilePhoto">
                    </div>

                    <button type="submit" class="btn btn-success" > Guardar </button>

                </form>
                
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</main>

<?php 
 $layout->PrintFooter();
?>