<?php 

class estudiantes {

    public $id;
    public $name;
    public $apellido;
    public $estadoId;
    public $carreraId;
    public $profilePhoto;

    private $utility;


    public function ___construct(){       

    }

    public function InicializeDate($id, $name, $apellido, $estadoId, $carreraId){

        $this->id = $id;
        $this->name = $name;
        $this->apellido = $apellido;
        $this->estadoId = $estadoId;
        $this->carreraId = $carreraId;

    }

    public function set($data){
        foreach($data as $key => $value) $this->{$key} = $value;
    }


    function getEstado(){
        $this->utility = new Utility();

        if($this->estadoId != 0 && $this->estadoId != null){
            return $this->utility->estado[$this->estadoId];
        }
    }

    function getCarrera(){
        $this->utility = new Utility();

        if($this->carreraId != 0 && $this->carreraId != null){
            return $this->utility->carrera[$this->carreraId];
        }
    }

 } 

?>