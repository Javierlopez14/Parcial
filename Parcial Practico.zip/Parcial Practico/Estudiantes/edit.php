<?php 

  require_once '../layout/layout.php';
  require_once '../helper/utility.php';
  require_once 'estudiantes.php';
  require_once '../service/IService.php';
  require_once 'estudianteServiceCookie.php';
  require_once '../helper/fileHandler/iFileHandler.php';
  require_once '../helper/fileHandler/JsonFileHandler.php';
  require_once 'estudianteServicefile.php';

  $layout = new Layout(true);
  $service = new EstudianteServiceFile();
  $utility = new Utility();

  if(isset($_GET['id'])){

    $estudianteeId = $_GET['id'];
    $element = $service->GetById($estudianteeId);

    if(isset($_POST['nombre']) && isset($_POST['apellido']) && 
     isset($_POST['estado']) && isset($_POST['carrera']) && isset($_FILES['profilePhoto'])){

    $updateEstudiante = new estudiantes();

    $updateEstudiante->InicializeDate($estudianteeId, $_POST['nombre'], $_POST['apellido'], $_POST['estado'], 
                                                      $_POST['carrera'],);

    $service->Update($estudianteeId, $updateEstudiante);
        
    header("Location: ../index.php");
    exit();
  }

  }
  else {
    header("Location: ../index.php");
    exit();
  }


?>


<?php 
$layout->PrintHeader();
?>

<main role="main">
   
    <div style="margin-top: 2%;" class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-dark text-light">
                    <h4>EDITANDO ESTUDIANTE</h4>
                    <a href="../index.php" class="btn btn-warning">Volver Atras</a>
                </div>
            <div class="card-body">

                <form enctype="multipart/form-data" action="edit.php?id=<?php echo $element->id;?>" method="POST">

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" value="<?php echo $element->name ?>" class="form-control" placeholder="Nombre" name="nombre">
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" value="<?php echo $element->apellido ?>" class="form-control" placeholder="Apellido" name="apellido">
                    </div>



                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select name="estado" id="estado" class="form-control">
                            <?php foreach($utility->estado as $id => $text): ?> 

                                <?php if($id == $element->estadoId): ?>

                                    <option selected value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php else :?>

                                    <option value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php endif;?>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="carrera">Carrera</label>
                        <select name="carrera" class="form-control" id="carrera">
                            <?php foreach($utility->carrera as $id => $text): ?>  

                                <?php if($id == $element->carreraId): ?>

                                    <option selected value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php else :?>

                                    <option value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php endif;?>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="margin-bottom: 3%;"  class="col-md-4">
                <div class="card" style="width: 18rem;">

              <?php if ($element->profilePhoto == "" || $element->profilePhoto == null ): ?>
                <img class="card-img-top" 
              style="height: 225px; width: 100%; display: block;" 
              src="<?php echo "../Asset/img/default.jpg" ?>" data-holder-rendered="true">

              <?php else : ?>
                <img class="card-img-top" 
              style="height: 225px; width: 100%; display: block;" 
              src="<?php echo "../Asset/img/estudiantes/" .  $element->profilePhoto; ?>" data-holder-rendered="true">

              <?php endif; ?>

                <div class="card-body">
                    <div class="form-group">
                        <label for="photo">FOTO DE PERFIL:</label>
                        <input type="file" class="form-control" placeholder="Photo" name="profilePhoto">
                    </div>
                 
                </div>
              </div>
            </div>

                    

                    <button type="submit" class="btn btn-success" > Guardar </button>

                </form>
                
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</main>

<?php 
 $layout->PrintFooter();
?>