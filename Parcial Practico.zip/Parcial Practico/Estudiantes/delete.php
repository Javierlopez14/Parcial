<?php

require_once '../helper/utility.php';
require_once 'estudiantes.php';
require_once '../service/IService.php';
require_once 'estudianteServiceCookie.php';
require_once '../helper/fileHandler/iFileHandler.php';
  require_once '../helper/fileHandler/JsonFileHandler.php';
  require_once 'estudianteServicefile.php';

$service = new EstudianteServiceFile();

$isContainId = isset($_GET['id']);

if($isContainId){

    $estudianteId = $_GET['id'];

    $service->Delete($estudianteId);

}

header("Location: ../index.php");
exit();

?>